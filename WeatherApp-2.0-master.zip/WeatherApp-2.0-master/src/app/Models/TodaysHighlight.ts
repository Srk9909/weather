export class TodaysHighlight{
    uvIndex:number;
    windStatus:number;
    sunrise: string;
    sunset: string;
    humidity:number;
    visibility:number;
    airQuality:number;
}