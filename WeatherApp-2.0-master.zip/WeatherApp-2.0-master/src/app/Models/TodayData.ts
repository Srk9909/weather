export class TodayData{
    time:string;
    summaryImage:string;
    temperature:number;
}