export class WeekData{
    day:string;
    summaryImage:string;
    tempMax:number;
    tempMin:number;
}